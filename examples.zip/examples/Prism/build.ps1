param(
    [Parameter(Mandatory=$true)][string]$GameDir,
    [Parameter(Mandatory=$true)][string]$ElementalBattlegroundsDll,
    [string]$ProfileDir = "",
    [switch]$Deploy
)

$ErrorActionPreference = "Stop"
$GameDir = (Resolve-Path $GameDir).Path
$ElementalBattlegroundsDll = (Resolve-Path $ElementalBattlegroundsDll).Path
$Managed = Join-Path $GameDir "ULTRAKILL_Data\Managed"

if ([string]::IsNullOrWhiteSpace($ProfileDir)) {
    $BepInExRoot = Join-Path $GameDir "BepInEx"
} else {
    $ProfileDir = (Resolve-Path $ProfileDir).Path
    $BepInExRoot = Join-Path $ProfileDir "BepInEx"
}

$BepInExCore = Join-Path $BepInExRoot "core"
$PluginsRoot = Join-Path $BepInExRoot "plugins"
$Project = Join-Path $PSScriptRoot "ElementalBattlegroundsExampleElement.csproj"
$BuiltDll = Join-Path $PSScriptRoot "bin\Release\netstandard2.1\ElementalBattlegroundsExampleElement.dll"

dotnet build $Project -c Release `
    -p:ManagedDir="$Managed" `
    -p:BepInExCoreDir="$BepInExCore" `
    -p:ElementalBattlegroundsDll="$ElementalBattlegroundsDll"
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

if ($Deploy) {
    $OutDir = Join-Path $PluginsRoot "ElementalBattlegroundsExampleElement"
    New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
    Copy-Item $BuiltDll (Join-Path $OutDir "ElementalBattlegroundsExampleElement.dll") -Force
    Write-Host "Deployed example addon to $OutDir"
}
