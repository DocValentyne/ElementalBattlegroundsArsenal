using System;
using System.IO;
using BepInEx;
using BepInEx.Logging;
using ElementalBattlegroundsMod.Api;
using UnityEngine;

namespace ElementalBattlegroundsExampleElement
{
    /// <summary>
    /// Minimal external element addon. This project intentionally references only EB's public
    /// ElementalBattlegroundsMod.Api namespace; it does not use reflection into EB or internal EB types.
    /// </summary>
    [BepInPlugin(Guid, Name, Version)]
    [BepInDependency(ElementalBattlegroundsApi.PluginGuid, BepInDependency.DependencyFlags.HardDependency)]
    public sealed class Plugin : BaseUnityPlugin
    {
        public const string Guid = "docvalentyne.ultrakill.elementalbattlegrounds.example";
        public const string Name = "Elemental Battlegrounds Example Element";
        public const string Version = "0.1.0";
        public const int TargetApiVersion = 1;
        public const string ElementStableId = "elementalbattlegroundsexample:prism";

        internal static ManualLogSource LogSource { get; private set; }

        private Texture2D iconTexture;
        private Sprite iconSprite;
        private bool registered;

        private void Awake()
        {
            LogSource = Logger;
            iconSprite = LoadEmbeddedSprite("ElementalBattlegroundsExampleElement.prism.png", out iconTexture);

            ElementRegistration prism = new ElementRegistration
            {
                // Pin the contract your addon was written against. Do not use EB's gameplay
                // version number as an API version.
                ApiVersion = TargetApiVersion,
                Id = ElementStableId,
                DisplayName = "Prism",
                Author = "EB Example Addon",
                Palette = ElementColorPalette.FromAccent(new Color(0.82f, 0.38f, 1f)),
                Icon = iconSprite,

                // Guide text belongs to the registration. An addon should not patch EB's guide UI.
                SimpleGuide =
                    "Prism is the developer example included with the EB source repository.\n\n" +
                    "Its five weapons intentionally keep their vanilla mechanics. The point is to " +
                    "demonstrate element registration, weapon chassis selection, coloring, icons, " +
                    "guides, stable IDs, persistence, and attach callbacks without depending on EB internals.",
                AdvancedGuide =
                    "PRISM — API EXAMPLE\n\n" +
                    "Revolver: Slab Marksman Revolver\n" +
                    "Close: Sawed-On Jackhammer\n" +
                    "Rapid: Attractor Sawblade Launcher\n" +
                    "Ultimate: Screwdriver Railcannon\n" +
                    "Explosive: S.R.S. Rocket Launcher\n\n" +
                    "Each cloned weapon receives ExampleWeaponAttachment through the public Attach callback. " +
                    "That component asks the public API for its runtime context and logs the stable element ID, " +
                    "family, slot, template, and Dual Wield state. No EB marker, registry, Harmony patch, " +
                    "WeaponCharges field, or GunSetter field is accessed directly.",

                // Legacy IDs are optional and are useful when an addon author renames an element.
                LegacyIds = new[] { "elementalbattlegroundsexample:old-prism" },

                // API v1 requires exactly one registration for all five families.
                Weapons = new[]
                {
                    Weapon(ElementWeaponFamily.Revolver, VanillaWeaponTemplate.SlabMarksmanRevolver, "Prismatic Marksman"),
                    Weapon(ElementWeaponFamily.Close, VanillaWeaponTemplate.SawedOnJackhammer, "Prismatic Jackhammer"),
                    Weapon(ElementWeaponFamily.Rapid, VanillaWeaponTemplate.AttractorSawbladeLauncher, "Prismatic Sawblade Launcher"),
                    Weapon(ElementWeaponFamily.Ultimate, VanillaWeaponTemplate.ScrewdriverRailcannon, "Prismatic Railcannon"),
                    Weapon(ElementWeaponFamily.Explosive, VanillaWeaponTemplate.SrsRocketLauncher, "Prismatic Cannon")
                }
            };

            registered = ElementalBattlegroundsApi.RegisterElement(prism, out string error);
            if (!registered)
                Logger.LogError("Could not register Prism: " + error);
            else
                Logger.LogInfo("Registered Prism against Elemental Battlegrounds API v" + TargetApiVersion + " (host supports v" + ElementalBattlegroundsApi.ApiVersion + ").");
        }

        private static ElementWeaponRegistration Weapon(
            ElementWeaponFamily family,
            VanillaWeaponTemplate template,
            string displayName)
        {
            return new ElementWeaponRegistration
            {
                Family = family,
                Template = template,
                DisplayName = displayName,

                // False means the vanilla chassis keeps its native secondary. Set OwnsSecondary
                // to true only when your addon actually replaces that secondary action; EB uses
                // the flag for compatibility plumbing such as Weapon Variant Binds.
                OwnsSecondary = false,

                // Attach is where addon-owned MonoBehaviours belong. Components placed on the
                // original slot weapon are naturally cloned by ULTRAKILL's Dual Wield system.
                Attach = context =>
                {
                    if (context.Weapon.GetComponent<ExampleWeaponAttachment>() == null)
                        context.Weapon.AddComponent<ExampleWeaponAttachment>();
                }
            };
        }

        private void OnDestroy()
        {
            if (registered)
            {
                if (!ElementalBattlegroundsApi.UnregisterElement(ElementStableId, out string error))
                    Logger.LogWarning("Could not unregister Prism: " + error);
                registered = false;
            }

            if (iconSprite != null)
                Destroy(iconSprite);
            if (iconTexture != null)
                Destroy(iconTexture);
            if (LogSource == Logger)
                LogSource = null;
        }

        private static Sprite LoadEmbeddedSprite(string resourceName, out Texture2D texture)
        {
            texture = null;
            try
            {
                using (Stream stream = typeof(Plugin).Assembly.GetManifestResourceStream(resourceName))
                {
                    if (stream == null)
                        return null;
                    byte[] data = new byte[stream.Length];
                    int offset = 0;
                    while (offset < data.Length)
                    {
                        int read = stream.Read(data, offset, data.Length - offset);
                        if (read <= 0)
                            break;
                        offset += read;
                    }
                    if (offset != data.Length)
                        return null;

                    texture = new Texture2D(2, 2, TextureFormat.RGBA32, false);
                    if (!ImageConversion.LoadImage(texture, data, false))
                    {
                        UnityEngine.Object.Destroy(texture);
                        texture = null;
                        return null;
                    }
                    texture.name = "Prism Example Element Icon";
                    Sprite sprite = Sprite.Create(
                        texture,
                        new Rect(0f, 0f, texture.width, texture.height),
                        new Vector2(0.5f, 0.5f));
                    sprite.name = "Prism Example Element Icon";
                    return sprite;
                }
            }
            catch (Exception exception)
            {
                LogSource?.LogWarning("Could not load Prism icon: " + exception.Message);
                if (texture != null)
                {
                    UnityEngine.Object.Destroy(texture);
                    texture = null;
                }
                return null;
            }
        }
    }

    /// <summary>
    /// Deliberately tiny example controller. Real addons can put their weapon mechanics in normal
    /// MonoBehaviours like this one. This sample only logs identity so it does not pretend that
    /// modifying a random vanilla field is a recommended custom-weapon architecture.
    /// </summary>
    public sealed class ExampleWeaponAttachment : MonoBehaviour
    {
        private void Start()
        {
            if (!ElementalBattlegroundsApi.TryGetWeaponContext(gameObject, out ElementWeaponContext context))
            {
                Plugin.LogSource?.LogWarning("ExampleWeaponAttachment could not resolve its EB weapon context.");
                return;
            }

            // ULTRAKILL destroys and recreates every Dual Wield copy whenever the player swaps
            // weapons. Logging every short-lived clone turns a harmless example callback into
            // measurable swap-time I/O with several Dual Wield powerups active. The component is
            // still present on clones; keep the demonstration log to the persistent slot owner.
            if (!context.IsDualWieldClone)
            {
                Plugin.LogSource?.LogInfo(
                    "Prism weapon attached: " + context.WeaponDisplayName +
                    " | family=" + context.Family +
                    " | slot=" + (context.SlotIndex + 1) +
                    " | template=" + context.Template);
            }
        }
    }
}
