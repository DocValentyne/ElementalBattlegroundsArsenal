# Prism — Elemental Battlegrounds API v1 example

> **Developer reference only.** Prism is not an official Elemental Battlegrounds element and is not intended to be installed as normal player content. It is deliberately unbalanced: because EB isolates resources per arsenal slot, duplicate vanilla chassis can create combinations such as multiple independent coin revolvers.

Prism is a small external BepInEx plugin showing how to add an element through the supported `ElementalBattlegroundsMod.Api` API without reflection into EB internals, copied EB source, `InternalsVisibleTo`, or special-case code in the main mod.

## What this example demonstrates

- a hard runtime dependency on Elemental Battlegrounds;
- API-v1 pinning with `TargetApiVersion = 1`;
- a stable namespaced element ID (`elementalbattlegroundsexample:prism`);
- an optional legacy ID;
- display name, author, palette, embedded icon, simple guide, and advanced guide;
- exactly one registered weapon for each of EB's five families;
- supported `VanillaWeaponTemplate` chassis descriptors instead of private `GunSetter` fields or prefab indices;
- addon-owned `MonoBehaviour` attachment through `ElementWeaponRegistration.Attach`;
- runtime identity lookup with `ElementalBattlegroundsApi.TryGetWeaponContext`;
- normal EB loadout/preset persistence and missing-addon recovery;
- EB's per-slot vanilla-resource isolation without the addon touching `WeaponCharges`.

Prism intentionally leaves all five chassis mechanically vanilla. The point is to demonstrate the API boundary. Real custom mechanics should normally live in addon-owned components and use ordinary ULTRAKILL/Harmony APIs where needed.

## Chassis used

- Revolver — Slab Marksman Revolver
- Close — Sawed-On Jackhammer
- Rapid — Attractor Sawblade Launcher
- Ultimate — Screwdriver Railcannon
- Explosive — S.R.S. Rocket Launcher

These choices intentionally exercise several vanilla resources that normally have only one owner. EB handles the mutually exclusive resources per arsenal slot automatically.

## Building

Build Elemental Battlegrounds first so you have `ElementalBattlegrounds.dll`, then run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

.\build.ps1 `
  -GameDir "C:\path\to\ULTRAKILL" `
  -ProfileDir "C:\path\to\your\r2modman\profile" `
  -ElementalBattlegroundsDll "C:\path\to\ElementalBattlegrounds.dll"
```

Add `-Deploy` if you want the script to copy the built example DLL into that profile's `BepInEx\plugins\ElementalBattlegroundsExampleElement` folder.

The project can also use a local `Directory.Build.props`; copy `Directory.Build.props.example` to `Directory.Build.props` and change the paths for your machine. Do not commit your machine-specific `Directory.Build.props`.

## The important API rules shown here

- Pin the API contract your addon was written against. Do not set `ApiVersion = ElementalBattlegroundsApi.ApiVersion` just to mean “latest.”
- Use a stable namespaced `Id` for persistence. Display names are not IDs.
- Register exactly one weapon for every EB family: Revolver, Close, Rapid, Ultimate, and Explosive.
- Use `VanillaWeaponTemplate`; do not depend on EB's internal prefab layout.
- Put addon behavior in your own components through `Attach` rather than reaching into EB internals.
- Dual Wield clones inherit attached components. Avoid expensive work or synchronous log spam on every clone; use `ElementWeaponContext.IsDualWieldClone` when appropriate.
- Set `OwnsSecondary = true` only if your addon actually replaces the chassis's native secondary action.
- Keep the backing texture/sprite alive while the element is registered if you provide an icon.

For the full contract, see the main repository's `CUSTOM_ELEMENT_API.md`.

## Persistence tests worth trying while developing an addon

1. Put the custom element in a slot, save a preset, restart, and confirm it persists.
2. Remove the addon DLL and restart. EB should retain the stable ID and show the slot as missing rather than overwrite it.
3. Restore the DLL and restart. The saved ID should resolve back to the element.
4. Change only `DisplayName`. Existing saves should still resolve because identity comes from `Id`.
5. If an ID genuinely must change, add the previous ID to `LegacyIds`.

## Thunderstore note

The included example `manifest.json` assumes Elemental Battlegrounds is published as:

```text
DocValentyne-Elemental_Battlegrounds_Arsenal-0.1.0
```

That makes the example show the correct dependency pattern for a published addon. If the final EB Thunderstore namespace or package name differs, update that one dependency before using this manifest as a template.

Prism itself does **not** need to be published or bundled with Elemental Battlegrounds. Keeping it under something like `examples/Prism/` in the source repository is enough.
